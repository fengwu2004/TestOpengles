#ifndef ARITH_INCLUDE
#define ARITH_INCLUDE

extern int arith_max(int x, int y);
extern int arith_min(int x, int y);
extern int arith_div(int x, int y);
extern int arith_mod(int x, int y);
extern int arith_ceiling(int x, int y);
extern int arith_floor(int x, int y);

#endif /*ARITH_INCLUDE*/
